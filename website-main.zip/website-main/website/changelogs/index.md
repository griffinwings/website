---
title: Changelogs
description: Changelogs of all Kotatsu stable releases.
lastUpdated: false
editLink: false
prev: false
next: false
footer: false
---

<script setup>
import ChangelogsList from "@theme/components/ChangelogsList.vue";
</script>

# Changelogs

Changelogs of all Kotatsu stable releases, which are also available [on GitHub](https://github.com/KotatsuApp/Kotatsu/releases).

<ChangelogsList />