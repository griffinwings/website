---
title: Settings
description: Frequently Asked Questions about various app settings.
footer: false
---

# Settings
Frequently Asked Questions about various app settings.

## Why is taking screenshots blocked?
Turn off **Screenshot policy** in <nav to="reader">.