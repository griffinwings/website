---
title: DMCA discaimer
lastUpdated: false
editLink: false
prev: false
next: false
sidebar: false
footer: false
---

# DMCA discaimer
The developers of this application does not have any affiliation with the content available in the app. It is collecting from the sources freely available through any web browser.