---
title: Огляд
description: Довідковий центр розділу Огляд.
lastUpdated: false
editLink: false
prev: false
next: false
footer: false
translator: CakesTwix
---
