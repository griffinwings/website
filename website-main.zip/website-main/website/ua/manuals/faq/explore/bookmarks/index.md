---
title: Закладки
description: Часті запитання про закладки.
footer: false
translator: CakesTwix
---
