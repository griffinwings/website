---
title: Локальне сховище
description: Часті запитання про локальне сховище.
footer: false
translator: CakesTwix
---
