---
title: Список змін
description: Список змін усіх стабільних випусків Kotatsu.
lastUpdated: false
editLink: false
prev: false
next: false
footer: false
translator: CakesTwix
---

<script setup>
import ChangelogsList from "@theme/components/ChangelogsList.vue";
</script>

# Список змін

Список змін усіх стабільних випусків Kotatsu, які також доступні [на GitHub](https://github.com/KotatsuApp/Kotatsu/releases).

<ChangelogsList />
