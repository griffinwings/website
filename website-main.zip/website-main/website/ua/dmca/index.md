---
title: DMCA discaimer
lastUpdated: false
editLink: false
prev: false
next: false
sidebar: false
footer: false
translator: CakesTwix
---

# Дисклеймер DMCA
Розробники цього додатку не мають жодного відношення до контенту, доступного в додатку. 
Він збирається з джерел, вільно доступних через будь-який веб-браузер.
